from django.db import models


class Tematica(models.Model):
    nombre = models.CharField(max_length=50)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre


class Plataforma(models.Model):
    nombre = models.CharField(max_length=50)
    web = models.URLField()

    def __str__(self):
        return self.nombre


class Podcast(models.Model):
    tematica = models.ForeignKey(Tematica, on_delete=models.CASCADE)
    plataformas = models.ManyToManyField(Plataforma)
    nombre = models.CharField(max_length=80)
    descripcion = models.TextField()
    fecha = models.DateField()

    def __str__(self):
        return self.nombre


class Comentario(models.Model):
    VALORACIONES = [
        (1, '1 ★ - Muy malo'),
        (2, '2 ★ - Regular'),
        (3, '3 ★ - Bueno'),
        (4, '4 ★ - Muy bueno'),
        (5, '5 ★ - Excelente'),
    ]

    podcast = models.ForeignKey(Podcast, on_delete=models.CASCADE, related_name='comentarios')
    autor = models.CharField(max_length=60)
    texto = models.TextField()
    valoracion = models.IntegerField(choices=VALORACIONES, default=5)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-fecha']

    def __str__(self):
        return f"{self.autor} - {self.podcast.nombre}"