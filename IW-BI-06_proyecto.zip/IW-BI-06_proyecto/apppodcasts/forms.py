from django import forms
from .models import Comentario


class ComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ['autor', 'valoracion', 'texto']
        labels = {
            'autor': 'Tu nombre',
            'valoracion': 'Valoración',
            'texto': 'Comentario',
        }
        widgets = {
            'autor': forms.TextInput(attrs={
                'placeholder': 'Escribe tu nombre o alias',
            }),
            'texto': forms.Textarea(attrs={
                'rows': 4,
                'placeholder': 'Comparte tu opinión sobre este podcast...',
            }),
        }