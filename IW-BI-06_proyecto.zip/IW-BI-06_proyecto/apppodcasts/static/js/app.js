"use strict";

document.addEventListener("DOMContentLoaded", () => {
    const main = document.querySelector("main");
    if (main) {
        main.classList.add("fade-in");
    }

    // Marcar si el usuario ha pasado por alguna vista de nuestra web
    const esDetallePodcast = /^\/podcasts\/\d+\/?$/.test(window.location.pathname);
    if (!esDetallePodcast || (document.referrer && document.referrer.includes(window.location.host))) {
        sessionStorage.setItem("navegacionInterna", "1");
    }

    // 1. BOTÓN "VOLVER A LA LISTA" INTELIGENTE (BOM: window.history + sessionStorage)
    const enlacesVolver = document.querySelectorAll(".js-volver");
    enlacesVolver.forEach((enlace) => {
        enlace.addEventListener("click", (event) => {
            const tieneOrigenInterno = sessionStorage.getItem("navegacionInterna") === "1";
            if (window.history.length > 1 && tieneOrigenInterno) {
                event.preventDefault();
                window.history.back();
            }
        });
    });

    // 2. NAVEGACIÓN "ANTERIOR / SIGUIENTE" SIN APILAR HISTORIAL (BOM: location.replace + keydown)
    const btnAnterior = document.getElementById("btn-anterior");
    const btnSiguiente = document.getElementById("btn-siguiente");

    const navegarSinApilar = (enlace) => {
        if (enlace && enlace.href) {
            window.location.replace(enlace.href);
        }
    };

    [btnAnterior, btnSiguiente].forEach((boton) => {
        if (boton) {
            boton.addEventListener("click", (event) => {
                event.preventDefault();
                navegarSinApilar(boton);
            });
        }
    });

    if (btnAnterior || btnSiguiente) {
        document.addEventListener("keydown", (event) => {
            const etiquetaActiva = document.activeElement.tagName;
            if (["INPUT", "TEXTAREA", "SELECT"].includes(etiquetaActiva)) {
                return;
            }

            if (event.key === "ArrowLeft" && btnAnterior) {
                navegarSinApilar(btnAnterior);
            } else if (event.key === "ArrowRight" && btnSiguiente) {
                navegarSinApilar(btnSiguiente);
            }
        });
    }

    // 3. FILTRADO INSTANTÁNEO CON RESALTADO EN NEGRITA (Eventos input + DOM)
    const buscador = document.getElementById("buscador-podcasts");
    const listaPodcasts = document.getElementById("lista-podcasts");

    const resaltarCoincidencia = (elemento, termino) => {
        const textoOriginal = elemento.textContent;
        if (!termino) {
            elemento.textContent = textoOriginal;
            return;
        }

        const terminoEscapado = termino.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const regex = new RegExp(`(${terminoEscapado})`, "gi");
        const partes = textoOriginal.split(regex);

        elemento.textContent = "";
        partes.forEach((parte) => {
            if (parte.toLowerCase() === termino.toLowerCase()) {
                const negrita = document.createElement("strong");
                negrita.className = "resaltado-busqueda";
                negrita.textContent = parte;
                elemento.append(negrita);
            } else if (parte) {
                elemento.append(document.createTextNode(parte));
            }
        });
    };

    if (buscador && listaPodcasts) {
        const items = listaPodcasts.querySelectorAll("li");
        const contador = document.getElementById("contador-podcasts");
        const sinResultados = document.getElementById("sin-resultados");

        buscador.addEventListener("input", () => {
            const termino = buscador.value.trim();
            const terminoMinusculas = termino.toLowerCase();
            let visibles = 0;

            items.forEach((item) => {
                const texto = item.textContent.toLowerCase();
                const coincide = texto.includes(terminoMinusculas);
                item.classList.toggle("oculto", !coincide);

                if (coincide) {
                    visibles++;
                    const enlaces = item.querySelectorAll("a");
                    enlaces.forEach((enlace) => resaltarCoincidencia(enlace, termino));
                }
            });

            if (contador) {
                contador.textContent = `Mostrando ${visibles} de ${items.length}`;
            }
            if (sinResultados) {
                sinResultados.classList.toggle("oculto", visibles > 0);
            }
        });
    }

    // 4. PUBLICACIÓN DE COMENTARIOS CON AJAX (Fetch API + Promises + JSON + DOM)
    const formComentario = document.getElementById("form-comentario");

    if (formComentario) {
        const btnPublicar = document.getElementById("btn-publicar");
        const mensajeAjax = document.getElementById("mensaje-ajax");
        const listaComentarios = document.getElementById("lista-comentarios");
        const totalComentarios = document.getElementById("total-comentarios");
        const sinComentarios = document.getElementById("sin-comentarios");

        const mostrarMensaje = (texto, tipo) => {
            mensajeAjax.textContent = texto;
            mensajeAjax.className = `mensaje-ajax ${tipo}`;
        };

        formComentario.addEventListener("submit", (event) => {
            event.preventDefault();

            const formData = new FormData(formComentario);
            btnPublicar.disabled = true;
            btnPublicar.textContent = "Publicando...";

            fetch(window.location.href, {
                method: "POST",
                body: formData,
                headers: {
                    "X-Requested-With": "XMLHttpRequest",
                    "X-CSRFToken": formData.get("csrfmiddlewaretoken")
                }
            })
                .then((response) => {
                    if (!response.ok) {
                        return Promise.reject("Revisa los campos del formulario.");
                    }
                    return response.json();
                })
                .then((data) => {
                    const articulo = document.createElement("article");
                    articulo.className = "comentario-item comentario-nuevo";

                    const cabecera = document.createElement("div");
                    cabecera.className = "comentario-cabecera";

                    const autorStrong = document.createElement("strong");
                    autorStrong.textContent = data.autor;

                    const etiquetaSpan = document.createElement("span");
                    etiquetaSpan.className = "etiqueta";
                    etiquetaSpan.textContent = data.valoracion;

                    const fechaSpan = document.createElement("span");
                    fechaSpan.className = "comentario-fecha";
                    fechaSpan.textContent = data.fecha;

                    const parrafo = document.createElement("p");
                    parrafo.textContent = data.texto;

                    cabecera.append(autorStrong, etiquetaSpan, fechaSpan);
                    articulo.append(cabecera, parrafo);
                    listaComentarios.prepend(articulo);

                    if (sinComentarios) {
                        sinComentarios.classList.add("oculto");
                    }
                    if (totalComentarios) {
                        totalComentarios.textContent = data.total;
                    }

                    formComentario.reset();
                    mostrarMensaje("¡Comentario publicado correctamente!", "exito");
                })
                .catch((error) => {
                    mostrarMensaje(`Error al publicar: ${error}`, "error");
                })
                .finally(() => {
                    btnPublicar.disabled = false;
                    btnPublicar.textContent = "Publicar comentario";
                });
        });
    }

    // 5. BOTÓN FLOTANTE "SUBIR ARRIBA" (Evento scroll + efecto suave)
    const btnSubir = document.getElementById("btn-subir");
    if (btnSubir) {
        window.addEventListener("scroll", () => {
            btnSubir.classList.toggle("visible", window.scrollY > 200);
        });

        btnSubir.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }
});